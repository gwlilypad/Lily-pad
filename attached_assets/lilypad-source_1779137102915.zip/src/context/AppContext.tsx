import { createContext, useContext } from "react";

export type PageId =
  | "home" | "padtype" | "bizsignup" | "signup" | "addpad"
  | "photointro" | "photo" | "availability" | "payment" | "account"
  | "find" | "spot" | "booking" | "confirm" | "driversignup" | "driveraccount"
  | "paddashboard" | "bookings" | "admin";

export interface BookingRec {
  id: number;
  spotId: number;
  addr: string;
  city: string;
  padType: string;
  startTs: number;
  endTs: number;
  pricePerHr: number;
  hostName: string;
  hostPhone: string;
  status: "active" | "cancelled";
}

export interface AppState {
  suAns: Record<number, string>;
  apAns: Record<number, string>;
  drAns: Record<number, string>;
  bizAns: Record<number, string>;
  bizPhotoCount: number;
  apNumPads: number;
  apLogoUrl: string;
  accountType: "renter" | "padRenter";
  hasBothAccounts: boolean;
  profilePhotoUrl: string;
  addingExtraPad: boolean;
  openAcctOnFind: boolean;
  bookings: BookingRec[];
  adminPreview: boolean;
  adminPreviewRole: "admin" | "staff" | null;
}

export interface AppCtx {
  goTo: (page: PageId) => void;
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
}

export const AppContext = createContext<AppCtx>({
  goTo: () => {},
  state: { suAns: {}, apAns: {}, drAns: {}, bizAns: {}, bizPhotoCount: 0, apNumPads: 1, apLogoUrl: "", accountType: "padRenter", hasBothAccounts: false, profilePhotoUrl: "", addingExtraPad: false, openAcctOnFind: false, bookings: [], adminPreview: false, adminPreviewRole: null },
  setState: () => {},
});

export function useApp() { return useContext(AppContext); }
