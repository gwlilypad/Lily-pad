import { useState, useEffect, useRef } from "react";
import { AppContext, type PageId, type AppState } from "@/context/AppContext";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import HomePage from "@/pages/HomePage";
import PadTypePage from "@/pages/PadTypePage";
import BizSignupPage from "@/pages/BizSignupPage";
import SignupPage from "@/pages/SignupPage";
import AddPadPage from "@/pages/AddPadPage";
import PhotoIntroPage from "@/pages/PhotoIntroPage";
import PhotoPage from "@/pages/PhotoPage";
import AvailabilityPage from "@/pages/AvailabilityPage";
import StripeConnectPage from "@/pages/StripeConnectPage";
import AccountPage from "@/pages/AccountPage";
import FindPage from "@/pages/FindPage";
import ConfirmPage from "@/pages/ConfirmPage";
import DriverSignupPage from "@/pages/DriverSignupPage";
import DriverAccountPage from "@/pages/DriverAccountPage";
import PadDashboardPage from "@/pages/PadDashboardPage";
import BookingsPage from "@/pages/BookingsPage";
import AdminPage from "@/pages/AdminPage";

const STORAGE_KEY = "lilypad.appState.v1";
const DEFAULT_STATE: AppState = {
  suAns: {}, apAns: {}, drAns: {}, bizAns: {},
  bizPhotoCount: 0, apNumPads: 1, apLogoUrl: "",
  accountType: "renter", hasBothAccounts: true,
  profilePhotoUrl: "", addingExtraPad: false, openAcctOnFind: false,
  bookings: [], adminPreview: false, adminPreviewRole: null,
};

// These are transient navigation/UI hints and shouldn't survive a refresh.
const TRANSIENT_KEYS: (keyof AppState)[] = ["addingExtraPad", "openAcctOnFind", "adminPreview", "adminPreviewRole"];

function loadInitialState(): AppState {
  if (typeof window === "undefined") return DEFAULT_STATE;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_STATE;
    const saved = JSON.parse(raw) as Partial<AppState>;
    const merged: AppState = { ...DEFAULT_STATE, ...saved };
    for (const k of TRANSIENT_KEYS) (merged as any)[k] = (DEFAULT_STATE as any)[k];
    return merged;
  } catch {
    return DEFAULT_STATE;
  }
}

export default function App() {
  const [page, setPage] = useState<PageId>("home");
  const [fading, setFading] = useState(false);
  const [state, setState] = useState<AppState>(loadInitialState);

  // Persist to local storage whenever state changes (small debounce so big
  // typing bursts don't thrash storage).
  const saveTimer = useRef<number | null>(null);
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (saveTimer.current != null) window.clearTimeout(saveTimer.current);
    saveTimer.current = window.setTimeout(() => {
      try {
        const toSave: Partial<AppState> = { ...state };
        for (const k of TRANSIENT_KEYS) delete (toSave as any)[k];
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(toSave));
      } catch {
        // localStorage can fail (private mode, quota with big photos) — ignore.
      }
    }, 250);
    return () => {
      if (saveTimer.current != null) window.clearTimeout(saveTimer.current);
    };
  }, [state]);

  function goTo(next: PageId) {
    setFading(true);
    setTimeout(() => {
      setPage(next);
      setFading(false);
    }, 200);
  }

  return (
    <AppContext.Provider value={{ goTo, state, setState }}>
      <div className={`screen${fading ? " fade-out" : ""}`}>
        {page === "home" && <HomePage />}
        {page === "padtype" && <PadTypePage />}
        {page === "bizsignup" && <BizSignupPage />}
        {page === "signup" && <SignupPage />}
        {page === "addpad" && <AddPadPage />}
        {page === "photointro" && <PhotoIntroPage />}
        {page === "photo" && <PhotoPage />}
        {page === "availability" && <AvailabilityPage />}
        {page === "payment" && <StripeConnectPage />}
        {page === "account" && <AccountPage />}
        {page === "find" && <ErrorBoundary><FindPage /></ErrorBoundary>}
        {page === "confirm" && <ConfirmPage />}
        {page === "driversignup" && <DriverSignupPage />}
        {page === "driveraccount" && <DriverAccountPage />}
        {page === "paddashboard" && <PadDashboardPage />}
        {page === "bookings" && <BookingsPage />}
        {page === "admin" && <AdminPage />}
      </div>
    </AppContext.Provider>
  );
}
