import { useState, useRef, useEffect } from "react";
import { useApp } from "@/context/AppContext";
import { PadSVG } from "@/components/PadSVG";
import chimeSound from "@assets/Ni_Sound_-_Cute_Interface_-_Clinking_Chimes_Notification_1775672054110.wav";

type Phase = "idle" | "held" | "drag" | "snap" | "drive" | "slide";

function AdminSlide() {
  return (
    <div style={{
      position: "absolute", left: "100%", top: 0, width: "100%", height: "100%",
      background: "#F4F7FA", display: "flex", flexDirection: "column", overflow: "hidden",
    }}>
      <div style={{
        background: "#0E1F40", padding: "48px 24px 28px",
        display: "flex", alignItems: "center", gap: 10, flexShrink: 0,
      }}>
        <PadSVG size={36} />
        <div>
          <p style={{ color: "rgba(255,255,255,0.4)", fontSize: 10, fontWeight: 600, letterSpacing: "0.18em", textTransform: "uppercase", margin: 0 }}>lily pad</p>
          <p style={{ color: "#fff", fontSize: 20, fontWeight: 700, margin: 0, letterSpacing: "-0.01em" }}>Admin</p>
        </div>
      </div>
      <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <p style={{ fontSize: 14, color: "rgba(14,31,64,0.3)", fontFamily: '"DM Sans", sans-serif' }}>Loading…</p>
      </div>
    </div>
  );
}

const CarSVG = () => (
  <svg width="135" height="66" viewBox="0 0 90 44" fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="carBody" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#f5f6f8"/>
        <stop offset="100%" stopColor="#d2d8e2"/>
      </linearGradient>
      <linearGradient id="carRoof" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#eceef2"/>
        <stop offset="100%" stopColor="#c8cdd8"/>
      </linearGradient>
    </defs>
    <ellipse cx="45" cy="42" rx="36" ry="3.5" fill="rgba(14,31,64,0.28)"/>
    <path d="M8 28 Q8 20 14 20 L22 20 L28 10 Q30 7 34 7 L58 7 Q62 7 64 10 L70 20 L76 20 Q82 20 82 28 L82 32 Q82 36 78 36 L12 36 Q8 36 8 32 Z" fill="url(#carBody)"/>
    <path d="M28 20 L34 9 Q36 7 38 7 L56 7 Q58 7 60 9 L66 20 Z" fill="url(#carRoof)"/>
    <path d="M60 20 L56 9 Q55 7.5 53 7.5 L50 7.5 L64 20 Z" fill="#b0c8dc" opacity="0.6"/>
    <path d="M34 9 Q36 7 38 7 L50 7.5 L64 20 L34 20 Z" fill="#b8d0e4" opacity="0.75"/>
    <path d="M28 20 L32 9 Q33 7.5 34 9 L34 20 Z" fill="#a8bcd0" opacity="0.55"/>
    <path d="M28 20 L32 8 Q30 6 29 8 L26 20 Z" fill="#b0c4d4" opacity="0.5"/>
    <path d="M38 9 Q44 7.5 52 8" stroke="white" strokeWidth="1" fill="none" opacity="0.5" strokeLinecap="round"/>
    <line x1="50" y1="20" x2="50" y2="35" stroke="rgba(0,0,0,0.09)" strokeWidth="0.8"/>
    <rect x="54" y="27" width="8" height="2" rx="1" fill="rgba(0,0,0,0.12)"/>
    <rect x="36" y="27" width="8" height="2" rx="1" fill="rgba(0,0,0,0.12)"/>
    <rect x="14" y="33" width="62" height="3" rx="1.5" fill="#b8bec8"/>
    <path d="M78 28 Q84 28 84 32 L84 34 Q84 36 82 36 L78 36 Z" fill="#c8cdd8"/>
    <rect x="79" y="22" width="5" height="6" rx="2" fill="#e8eef8" opacity="0.9"/>
    <path d="M12 28 Q6 28 6 32 L6 34 Q6 36 8 36 L12 36 Z" fill="#c0c6d2"/>
    <rect x="6" y="22" width="5" height="6" rx="2" fill="#e87070" opacity="0.75"/>
    <circle cx="67" cy="36" r="8" fill="#22262e"/>
    <circle cx="67" cy="36" r="5.5" fill="#383d4a"/>
    <circle cx="67" cy="36" r="2.5" fill="#606472"/>
    <circle cx="67" cy="36" r="1.2" fill="#888ea0"/>
    <circle cx="23" cy="36" r="8" fill="#22262e"/>
    <circle cx="23" cy="36" r="5.5" fill="#383d4a"/>
    <circle cx="23" cy="36" r="2.5" fill="#606472"/>
    <circle cx="23" cy="36" r="1.2" fill="#888ea0"/>
    <path d="M10 30 Q10 20 14 20 L22 20 Q20 22 18 30 Z" fill="url(#carBody)"/>
    <path d="M72 20 L76 20 Q82 20 82 28 L82 30 Q78 22 74 20 Z" fill="url(#carBody)"/>
  </svg>
);

const SPLIT = 61; // % — navy top / white bottom divider

export default function HomePage() {
  const { goTo, setState } = useApp();
  const [modeToggle, setModeToggle] = useState<"renter" | "padRenter">("renter");
  const [modalOpen, setModalOpen]       = useState(false);
  const [modalSuccess, setModalSuccess] = useState(false);
  const [typeVal, setTypeVal]           = useState<"driver" | "host">("driver");
  const [refCode, setRefCode]           = useState("");

  const [phase, setPhase]               = useState<Phase>("idle");
  const [overlayCarPos, setOverlayCarPos] = useState({ x: 0, y: 0 });

  const pageRef       = useRef<HTMLDivElement>(null);
  const carRef        = useRef<HTMLDivElement>(null);
  const padElRef      = useRef<HTMLDivElement>(null);
  const padInnerRef   = useRef<HTMLDivElement>(null);
  const audioRef      = useRef<HTMLAudioElement | null>(null);

  const holdTimerRef    = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const ptStart         = useRef({ x: 0, y: 0 });
  const isDragging      = useRef(false);
  const snapTriggered   = useRef(false);

  const angleRef     = useRef(0);
  const angVelRef    = useRef(0);
  const padPosRef    = useRef({ x: 0, y: 0 });
  const rafRef       = useRef<number>(0);
  const phaseRef     = useRef<Phase>("idle");
  const totalDistRef = useRef(200);

  useEffect(() => { phaseRef.current = phase; }, [phase]);

  useEffect(() => {
    if (phase !== "held" && phase !== "drag") {
      cancelAnimationFrame(rafRef.current);
      if (phase === "idle") {
        angVelRef.current = 0;
        if (padElRef.current)
          padElRef.current.style.transform = "translate(-50%, -50%) rotate(0deg)";
      }
      return;
    }
    let lastT = performance.now();
    function tick(now: number) {
      const dt = Math.min((now - lastT) / 1000, 0.05);
      lastT = now;
      angleRef.current += angVelRef.current * dt;
      const pos = padPosRef.current;
      const ph  = phaseRef.current;
      if (padElRef.current && (ph === "held" || ph === "drag")) {
        padElRef.current.style.transform =
          `translate(calc(-50% + ${pos.x}px), calc(-50% + ${pos.y}px)) rotate(${angleRef.current}deg)`;
      }
      rafRef.current = requestAnimationFrame(tick);
    }
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [phase]);

  useEffect(() => {
    if (phase !== "slide") return;
    const t = setTimeout(() => goTo("admin"), 640);
    return () => clearTimeout(t);
  }, [phase]);

  function applyCode() { if (refCode.trim()) setModalSuccess(true); }
  function closeModal() { setModalOpen(false); setRefCode(""); setModalSuccess(false); }

  function onPadDown(e: React.PointerEvent) {
    if (phase !== "idle") return;
    e.preventDefault();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    ptStart.current       = { x: e.clientX, y: e.clientY };
    padPosRef.current     = { x: 0, y: 0 };
    snapTriggered.current = false;

    if (carRef.current && padElRef.current) {
      const cR = carRef.current.getBoundingClientRect();
      const pR = padElRef.current.getBoundingClientRect();
      totalDistRef.current = Math.max(Math.abs((pR.top + pR.height / 2) - (cR.top + cR.height / 2)), 1);
    }

    try {
      audioRef.current = new Audio(chimeSound);
      audioRef.current.volume = 0.85;
      audioRef.current.load();
    } catch { /* noop */ }

    holdTimerRef.current = setTimeout(() => {
      angVelRef.current = 180;
      setPhase("held");
      setTimeout(() => { isDragging.current = true; setPhase("drag"); }, 80);
    }, 400);
  }

  function onPadMove(e: React.PointerEvent) {
    if (!isDragging.current || snapTriggered.current) return;
    const dy      = e.clientY - ptStart.current.y;
    const clamped = Math.max(-totalDistRef.current, Math.min(0, dy));
    padPosRef.current = { x: 0, y: clamped };

    const progress    = Math.min(1, Math.abs(clamped) / totalDistRef.current);
    angVelRef.current = 180 + Math.pow(progress, 3) * 3600;

    const scale = 1.0 + Math.pow(progress, 2) * 0.65;
    padElRef.current?.style.setProperty("--pad-scale", scale.toFixed(3));
  }

  function onPadUp(e: React.PointerEvent) {
    clearTimeout(holdTimerRef.current);

    if (!isDragging.current || snapTriggered.current) {
      isDragging.current = false;
      angVelRef.current  = 0;
      padPosRef.current  = { x: 0, y: 0 };
      padElRef.current?.style.setProperty("--pad-scale", "1");
      setPhase("idle");
      return;
    }

    const dy = e.clientY - ptStart.current.y;
    if (dy >= 0) {
      isDragging.current = false;
      angVelRef.current  = 0;
      padPosRef.current  = { x: 0, y: 0 };
      padElRef.current?.style.setProperty("--pad-scale", "1");
      setPhase("idle");
      return;
    }

    snapTriggered.current = true;
    isDragging.current    = false;

    if (pageRef.current && carRef.current) {
      const pageR = pageRef.current.getBoundingClientRect();
      const cR    = carRef.current.getBoundingClientRect();
      setOverlayCarPos({
        x: cR.left + cR.width  / 2 - pageR.left,
        y: cR.top  + cR.height / 2 - pageR.top,
      });
    }

    cancelAnimationFrame(rafRef.current);
    angVelRef.current = 0;

    try {
      const a = audioRef.current ?? new Audio(chimeSound);
      a.currentTime = 0;
      a.volume = 0.85;
      a.play().catch(() => {});
    } catch { /* noop */ }

    setPhase("snap");
    setTimeout(() => {
      setPhase("drive");
      setTimeout(() => setPhase("slide"), 220);
    }, 80);
  }

  const inOverlay  = phase === "snap" || phase === "drive" || phase === "slide";
  const carDriving = phase === "drive" || phase === "slide";

  return (
    <div
      className="page active"
      ref={pageRef}
      style={{
        position: "relative",
        overflow: "hidden",
        transform:  phase === "slide" ? "translateX(-100%)" : "translateX(0)",
        transition: phase === "slide" ? "transform 0.60s cubic-bezier(0.55,0,0.1,1)" : "none",
        fontFamily: "'Nunito', 'DM Sans', sans-serif",
      }}
    >
      {phase === "slide" && <AdminSlide />}

      {/* ── Background halves ── */}
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: `${SPLIT}%`, background: "#0E1F40", zIndex: 0 }} />
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: `${100 - SPLIT}%`, background: "#fff", zIndex: 0 }} />

      {/* ── NAVY SECTION ── */}
      <div style={{
        position: "absolute", top: 0, left: 0, right: 0, height: `${SPLIT}%`,
        display: "flex", flexDirection: "column",
        padding: "0 20px", zIndex: 5,
        boxSizing: "border-box",
      }}>
        {/* Top bar */}
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          paddingTop: 52, paddingBottom: 0,
          flexShrink: 0,
        }}>
          {/* Mode toggle — tap a side to set account type and enter the map */}
          <div style={{
            display: "flex", alignItems: "center",
            background: "rgba(255,255,255,0.10)", borderRadius: 24,
            padding: 3, gap: 2,
          }}>
            {(["renter", "padRenter"] as const).map(mode => {
              const on = modeToggle === mode;
              return (
                <button
                  key={mode}
                  onClick={() => {
                    setModeToggle(mode);
                    setState(s => ({ ...s, accountType: mode }));
                    goTo("find");
                  }}
                  style={{
                    display: "flex", alignItems: "center", gap: 5,
                    padding: "6px 11px", borderRadius: 20, border: "none",
                    background: on ? "#8DD63F" : "transparent",
                    cursor: "pointer", fontFamily: "'DM Sans',sans-serif",
                    fontSize: 12, fontWeight: 700, letterSpacing: -0.1,
                    color: on ? "#0E1F40" : "rgba(255,255,255,0.60)",
                    transition: "all 0.18s",
                    boxShadow: on ? "0 1px 6px rgba(141,214,63,0.30)" : "none",
                  }}
                >
                  {on && <PadSVG size={13} />}
                  {mode === "renter" ? "Renter" : "Driver"}
                </button>
              );
            })}
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button
              onClick={() => goTo("find")}
              style={{ width: 36, height: 36, borderRadius: "50%", background: "rgba(255,255,255,0.12)", border: "none", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
              </svg>
            </button>
            <button
              style={{ width: 36, height: 36, borderRadius: "50%", background: "rgba(255,255,255,0.12)", border: "none", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>
              </svg>
            </button>
          </div>
        </div>

        {/* Car */}
        <div style={{ display: "flex", justifyContent: "center", marginTop: 24, flexShrink: 0 }}>
          <div ref={carRef} style={{ opacity: inOverlay ? 0 : 1, transition: "opacity 0.06s", filter: "drop-shadow(0 6px 20px rgba(0,0,0,0.35))" }}>
            <CarSVG />
          </div>
        </div>

        {/* FOR DRIVERS label */}
        <p style={{
          textAlign: "center", margin: "18px 0 6px",
          fontSize: 11, fontWeight: 700, letterSpacing: "0.18em",
          color: "#8DD63F", textTransform: "uppercase", flexShrink: 0,
        }}>For Drivers</p>

        {/* Headline */}
        <h1 style={{
          textAlign: "center", margin: "0 0 20px",
          fontSize: 32, fontWeight: 800, color: "#fff",
          lineHeight: 1.15, letterSpacing: "-0.03em", flexShrink: 0,
        }}>
          Find parking<br />near you.
        </h1>

        {/* Find a pad button */}
        <button
          onClick={() => { setState(s => ({ ...s, accountType: "renter" })); goTo("driversignup"); }}
          style={{
            width: "100%", background: "#8DD63F", color: "#0E1F40",
            border: "none", borderRadius: 50, padding: "16px",
            fontSize: 16, fontWeight: 800, cursor: "pointer",
            letterSpacing: "-0.01em", flexShrink: 0,
            boxShadow: "0 4px 18px rgba(141,214,63,0.30)",
          }}
        >
          Find a pad
        </button>
      </div>

      {/* ── WHITE SECTION ── */}
      <div style={{
        position: "absolute", bottom: 0, left: 0, right: 0, height: `${100 - SPLIT}%`,
        display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "flex-end",
        padding: "0 20px 28px", zIndex: 5, boxSizing: "border-box", gap: 12,
      }}>
        {/* FOR PAD RENTERS label */}
        <p style={{
          margin: 0, fontSize: 11, fontWeight: 700, letterSpacing: "0.18em",
          color: "rgba(14,31,64,0.38)", textTransform: "uppercase", textAlign: "center",
        }}>For Pad Renters</p>

        {/* Sub headline */}
        <p style={{
          margin: 0, fontSize: 17, fontWeight: 600, color: "#0E1F40",
          textAlign: "center", letterSpacing: "-0.01em",
        }}>Rent your pad. Earn money.</p>

        {/* List my lily pad button */}
        <button
          onClick={() => { setState(s => ({ ...s, accountType: "padRenter" })); goTo("padtype"); }}
          style={{
            width: "100%", background: "transparent",
            border: "2px solid #0E1F40", borderRadius: 50,
            padding: "14px", fontSize: 15, fontWeight: 700,
            color: "#0E1F40", cursor: "pointer", letterSpacing: "-0.01em",
          }}
        >
          List my lily pad
        </button>

        {/* Referral */}
        <div
          onClick={() => setModalOpen(true)}
          style={{ fontSize: 12, color: "rgba(14,31,64,0.38)", cursor: "pointer", textDecoration: "underline", textDecorationColor: "rgba(14,31,64,0.2)" }}
        >
          Have a referral code?
        </div>
      </div>

      {/* ── DRAGGABLE PAD — sits on the divider ── */}
      <div
        ref={padElRef}
        onPointerDown={onPadDown}
        onPointerMove={onPadMove}
        onPointerUp={onPadUp}
        onPointerCancel={() => {
          clearTimeout(holdTimerRef.current);
          isDragging.current = false;
          angVelRef.current  = 0;
          padPosRef.current  = { x: 0, y: 0 };
          padElRef.current?.style.setProperty("--pad-scale", "1");
          setPhase("idle");
        }}
        onContextMenu={e => e.preventDefault()}
        style={{
          position: "absolute",
          left: "50%",
          top: `${SPLIT}%`,
          transform: "translate(-50%, -50%) rotate(0deg)",
          zIndex: 20,
          touchAction: "none",
          cursor: phase === "drag" ? "grabbing" : "default",
          opacity: inOverlay ? 0 : 1,
          transition: "opacity 0.08s",
          userSelect: "none",
          WebkitUserSelect: "none",
        }}
      >
        <div
          ref={padInnerRef}
          style={{
            transform: "scale(var(--pad-scale, 1))",
            transition: phase === "drag" ? "none" : "transform 0.28s cubic-bezier(0.34,1.56,0.64,1), filter 0.2s",
            filter: phase === "held"
              ? "drop-shadow(0 6px 16px rgba(0,0,0,0.38)) drop-shadow(0 0 10px rgba(141,214,63,0.3))"
              : "drop-shadow(0 12px 24px rgba(0,0,0,0.35))",
          }}
        >
          <PadSVG />
        </div>
      </div>

      {/* ── Snap / drive overlay ── */}
      {inOverlay && (
        <div style={{ position: "absolute", inset: 0, zIndex: 100, pointerEvents: "none" }}>
          <div style={{
            position: "absolute", inset: 0,
            background: "rgba(14,31,64,0.48)",
            backdropFilter: "blur(3px)",
            opacity: phase === "snap" ? 1 : 0,
            transition: "opacity 0.3s ease",
          }} />
          <div style={{
            position: "absolute", inset: 0,
            transform: carDriving ? "translateX(-140%)" : "translateX(0)",
            transition: phase === "drive" ? "transform 0.87s cubic-bezier(0.25,0.46,0.45,0.94)" : "none",
          }}>
            <div style={{ position: "absolute", left: overlayCarPos.x, top: overlayCarPos.y + 7, zIndex: 1 }}>
              <div style={{ transform: "translate(-50%, -50%)", filter: "drop-shadow(0 0 14px rgba(141,214,63,0.7))" }}>
                <PadSVG />
              </div>
            </div>
            <div style={{ position: "absolute", left: overlayCarPos.x, top: overlayCarPos.y, zIndex: 2 }}>
              <div style={{ transform: "translate(-50%, -50%) scale(1.06)" }}>
                <CarSVG />
              </div>
            </div>
            <div style={{
              position: "absolute",
              left: overlayCarPos.x, top: overlayCarPos.y,
              transform: "translate(-50%, -50%)",
              zIndex: 0, width: 110, height: 110, borderRadius: "50%",
              background: "radial-gradient(circle, rgba(141,214,63,0.22) 0%, rgba(141,214,63,0) 70%)",
              animation: "glow-burst 0.45s ease-out forwards",
            }} />
          </div>
        </div>
      )}

      {/* ── Referral modal ── */}
      <div
        className={`modal-overlay${modalOpen ? " show" : ""}`}
        onClick={(e) => { if (e.target === e.currentTarget) closeModal(); }}
      >
        <div className="modal-sheet">
          <div className="modal-handle" />
          {!modalSuccess ? (
            <>
              <p className="modal-title">Enter referral code</p>
              <p className="modal-sub">Choose your account type then enter the code you received.</p>
              <div className="modal-type-row">
                <button className={`type-btn${typeVal === "driver" ? " sel" : ""}`} onClick={() => setTypeVal("driver")}>Driver</button>
                <button className={`type-btn${typeVal === "host" ? " sel" : ""}`} onClick={() => setTypeVal("host")}>Pad Renter</button>
              </div>
              <div className="modal-input-wrap">
                <input className="modal-input" placeholder="Enter code" maxLength={10} value={refCode} onChange={e => setRefCode(e.target.value)} />
              </div>
              <button className="modal-apply-btn" onClick={applyCode}>Apply code</button>
              <p className="modal-dismiss" onClick={closeModal}>Dismiss</p>
            </>
          ) : (
            <div className="modal-success" style={{ display: "flex" }}>
              <div className="success-icon">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#8DD63F" strokeWidth="2.5"><path d="M20 6L9 17l-5-5"/></svg>
              </div>
              <p style={{ fontSize: 17, fontWeight: 300, color: "#0E1F40", marginBottom: 5 }}>
                {typeVal === "host" ? "Code applied — welcome!" : "Code applied!"}
              </p>
              <p style={{ fontSize: 12, fontWeight: 300, color: "rgba(14,31,64,0.4)", lineHeight: 1.6 }}>
                {typeVal === "host" ? "Your $10 pad renter credit will be applied after your first booking." : "Your driver discount will be applied on your first booking."}
              </p>
              <button className="modal-apply-btn" style={{ marginTop: 18 }} onClick={closeModal}>Done</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
