import type { PageId } from "@/context/AppContext";

interface TabBarProps {
  active: "find" | "account" | "driveraccount";
  goTo: (page: PageId) => void;
  mode?: "driver" | "host";
}

export default function TabBar({ active, goTo, mode = "host" }: TabBarProps) {
  if (mode === "driver") {
    return (
      <div className="tab-bar">
        <button className={`tab${active === "find" ? " active-tab" : ""}`} onClick={() => goTo("find")}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
            <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
          </svg>
          <span className="tab-lbl">Find</span>
        </button>
        <button className={`tab${active === "driveraccount" ? " active-tab" : ""}`} onClick={() => goTo("driveraccount")}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" />
          </svg>
          <span className="tab-lbl">Account</span>
        </button>
      </div>
    );
  }

  return (
    <div className="tab-bar">
      <button className={`tab${active === "find" ? " active-tab" : ""}`} onClick={() => goTo("find")}>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
          <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
        </svg>
        <span className="tab-lbl">Find</span>
      </button>
      <button className={`tab${active === "account" ? " active-tab" : ""}`} onClick={() => goTo("account")}>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
          <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" />
        </svg>
        <span className="tab-lbl">Account</span>
      </button>
    </div>
  );
}
